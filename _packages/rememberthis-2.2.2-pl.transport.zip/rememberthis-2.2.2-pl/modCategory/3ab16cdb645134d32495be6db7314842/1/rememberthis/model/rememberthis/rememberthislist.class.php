<?php
/**
 * @package rememberthis
 */
class RememberThisList extends xPDOSimpleObject {}
?>