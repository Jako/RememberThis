<?php
$_lang['rememberthis.add'] = 'Remember';
$_lang['rememberthis.delete'] = 'Delete';
$_lang['rememberthis.noresultstext'] = 'The List is empty';
