<?php
$_lang['rememberthis.add'] = 'Merken';
$_lang['rememberthis.delete'] = 'Entfernen';
$_lang['rememberthis.noresultstext'] = 'Die Liste ist leer';
