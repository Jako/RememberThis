<?php
$_lang['rememberthis.rememberthisadd.addId'] = 'This value (and the correspondenting item title) is added to the list.';
$_lang['rememberthis.rememberthisadd.addTpl'] = 'Template for the add link.';
$_lang['rememberthis.rememberthislist.rowTpl'] = 'Row template for the output of a list element.';
$_lang['rememberthis.rememberthislist.outerTpl'] = 'Outer template for the output of the list, if the list is not empty.';
$_lang['rememberthis.rememberthislist.wrapperTpl'] = 'Wrapper template for the outer output or the empty output.';
$_lang['rememberthis.rememberthislist.noResultsTpl'] = 'Template that is displayed, if the list is empty.';
$_lang['rememberthis.rememberthislist.scriptTpl'] = 'Template for the javascript call.';
$_lang['rememberthis.rememberthislist.jsonList'] = 'Output a JSON encoded array of associative arrays of element identifiers and element itemproperties.';
$_lang['rememberthis.rememberthislist.clearList'] = 'Clear the list after running the hook.';
$_lang['rememberthis.rememberthishook.rememberRowTpl'] = 'Row template for the output of a list element.';
$_lang['rememberthis.rememberthishook.rememberOuterTpl'] = 'Outer template for the output of the list, if the list is not empty.';
$_lang['rememberthis.rememberthislist.rememberWrapperTpl'] = 'Wrapper template for the outer output or the empty output.';
$_lang['rememberthis.rememberthislist.rememberNoResultsTpl'] = 'Template that is displayed, if the list is empty.';
