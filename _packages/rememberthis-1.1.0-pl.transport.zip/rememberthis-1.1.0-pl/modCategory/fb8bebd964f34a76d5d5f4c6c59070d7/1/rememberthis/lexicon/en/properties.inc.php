<?php
$_lang['prop_rememberthis.mode'] = 'Output mode of the snippet';
$_lang['prop_rememberthis.addId'] = 'If the output mode is \'add\', this value (and the correspondenting data) is added to the list.';
$_lang['prop_rememberthis.add'] = 'Add';
$_lang['prop_rememberthis.display'] = 'Display';
