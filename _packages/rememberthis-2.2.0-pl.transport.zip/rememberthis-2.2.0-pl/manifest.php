<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '0e82dbf1cec6d12187945e15020a290e',
      'native_key' => 'rememberthis',
      'filename' => 'modNamespace/dae69038c3bffd07dcc42fb8376b7a47.vehicle',
      'namespace' => 'rememberthis',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3a7c364dee176b344b23bd9622a9d50',
      'native_key' => 'rememberthis.rowTpl',
      'filename' => 'modSystemSetting/8c7a068b96e3b2bb70cd2be58a7d28be.vehicle',
      'namespace' => 'rememberthis',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ffd25a1dcf272b3899ae666c282fe02',
      'native_key' => 'rememberthis.outerTpl',
      'filename' => 'modSystemSetting/ed5bea550ac86d9ad4e482115cc86c19.vehicle',
      'namespace' => 'rememberthis',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c6b0bf8a889418fd04425ad1c6b9e83',
      'native_key' => 'rememberthis.wrapperTpl',
      'filename' => 'modSystemSetting/170dba2bd95296fa4a8741d3244f65b9.vehicle',
      'namespace' => 'rememberthis',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de1344e4a997bd73e65ae2467c055e2b',
      'native_key' => 'rememberthis.addTpl',
      'filename' => 'modSystemSetting/cd193d8e74fa410a36c9ea73380177f2.vehicle',
      'namespace' => 'rememberthis',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc66aaf6eb13fe7d492b0f69ea232aee',
      'native_key' => 'rememberthis.noResultsTpl',
      'filename' => 'modSystemSetting/f9334fa71cb9c26b1995bb95097a3aca.vehicle',
      'namespace' => 'rememberthis',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7401f064cbb08159f0bc6ec853255adc',
      'native_key' => 'rememberthis.scriptTpl',
      'filename' => 'modSystemSetting/a0b8e6e36e4e2e9dacfec7c21533289c.vehicle',
      'namespace' => 'rememberthis',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fba106ee22e477094bb7945a872e28d',
      'native_key' => 'rememberthis.showZeroCount',
      'filename' => 'modSystemSetting/5cb7cfa3c763c3f2c07ee0a2512b7ee7.vehicle',
      'namespace' => 'rememberthis',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21d2bcb51c4d16fff98fd60a24b393c5',
      'native_key' => 'rememberthis.itemTitleTpl',
      'filename' => 'modSystemSetting/04509aa1df4953417c744f2718e270f2.vehicle',
      'namespace' => 'rememberthis',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43f8497a3beb1ea6cb3ec7a8ce060f22',
      'native_key' => 'rememberthis.ajaxLoaderImg',
      'filename' => 'modSystemSetting/46a3131c3103ea2bbc47b14669d2ba0b.vehicle',
      'namespace' => 'rememberthis',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e6724aa888d2a87a25aef5fce3d7874',
      'native_key' => 'rememberthis.tvPrefix',
      'filename' => 'modSystemSetting/6d4ae24b910057a8bf3f7e508e768013.vehicle',
      'namespace' => 'rememberthis',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd21299bd8b8a50baa558f754b087528',
      'native_key' => 'rememberthis.queryAdd',
      'filename' => 'modSystemSetting/d124ff58c6f3344c1d9251b98c82a3c8.vehicle',
      'namespace' => 'rememberthis',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5cdf20ec053dcc60620c080534cc071d',
      'native_key' => 'rememberthis.queryDelete',
      'filename' => 'modSystemSetting/5c8f4de1ccbe8f36ab074fc3145ffa66.vehicle',
      'namespace' => 'rememberthis',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf4315ed35f8754141ee93137db2bbab',
      'native_key' => 'rememberthis.language',
      'filename' => 'modSystemSetting/db6a6f4416350ce9369039be7ca0392b.vehicle',
      'namespace' => 'rememberthis',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29436cd24ef551d40b4b4727a2fe795f',
      'native_key' => 'rememberthis.tplPath',
      'filename' => 'modSystemSetting/f27031771dbf62286ce58bdc0e0afbcb.vehicle',
      'namespace' => 'rememberthis',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a29680fcbebdaf7ac112661d3a550f65',
      'native_key' => 'rememberthis.packagename',
      'filename' => 'modSystemSetting/fd751fc7d6812495e5a33dc82ba6999d.vehicle',
      'namespace' => 'rememberthis',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d793ce951cea721d6be9403659b1267',
      'native_key' => 'rememberthis.classname',
      'filename' => 'modSystemSetting/4cebe08bc639a32c0dbf149e87fb392d.vehicle',
      'namespace' => 'rememberthis',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef3c65daf2a27f834c762a54676f6f76',
      'native_key' => 'rememberthis.keyname',
      'filename' => 'modSystemSetting/e77ee6b1571188e2ed90ba622b932d38.vehicle',
      'namespace' => 'rememberthis',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2860e44566659d1f9a74ff2beb622516',
      'native_key' => 'rememberthis.joins',
      'filename' => 'modSystemSetting/358456b8e3f42f10b6540dd10c3f2c91.vehicle',
      'namespace' => 'rememberthis',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8920b901a6c55ada053471936fc6dfb9',
      'native_key' => 'rememberthis.jQueryPath',
      'filename' => 'modSystemSetting/7fa085853e466762f8b94153a28fe7e1.vehicle',
      'namespace' => 'rememberthis',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8f957bfce262e0c6895821a56469826',
      'native_key' => 'rememberthis.includeScripts',
      'filename' => 'modSystemSetting/06e82f606c7f97e817086f2a48418464.vehicle',
      'namespace' => 'rememberthis',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4111fb21e1206de823f333679fc77923',
      'native_key' => 'rememberthis.includeCss',
      'filename' => 'modSystemSetting/d2f02ff2f932325c413a58e28cac6734.vehicle',
      'namespace' => 'rememberthis',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6214ec95f9d9f60ef7c0f58e5cfa6e27',
      'native_key' => 'rememberthis.useCookie',
      'filename' => 'modSystemSetting/ae8b7411f3b1dca61d55c5639752eaac.vehicle',
      'namespace' => 'rememberthis',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8124441bdd522e0f3832d3b56959d7b4',
      'native_key' => 'rememberthis.cookieName',
      'filename' => 'modSystemSetting/23fc07a03e77cd0d993ccb5e70d1dea0.vehicle',
      'namespace' => 'rememberthis',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc73faabf24676881ecf50bee6b854dd',
      'native_key' => 'rememberthis.cookieExpireDays',
      'filename' => 'modSystemSetting/f2caa2e77eb76185b98977ac71d2521f.vehicle',
      'namespace' => 'rememberthis',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9120d9e0424800e487a946ba6fc52b5',
      'native_key' => 'rememberthis.useDatabase',
      'filename' => 'modSystemSetting/252203e42f45c2f68745dbbbcba1e88a.vehicle',
      'namespace' => 'rememberthis',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7dc8c3bda0abada9c1f429a57695ee37',
      'native_key' => 'rememberthis.debug',
      'filename' => 'modSystemSetting/ff79e396b321af63b8d6d4c4a5d68d8e.vehicle',
      'namespace' => 'rememberthis',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'abde8a7c573cfcded04a3ee76af8fdff',
      'native_key' => NULL,
      'filename' => 'modCategory/021bce522a353e20f831a0d72446c831.vehicle',
      'namespace' => 'rememberthis',
    ),
  ),
);