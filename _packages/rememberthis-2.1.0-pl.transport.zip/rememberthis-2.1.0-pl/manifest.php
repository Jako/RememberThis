<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a2d46763b70e31dcc41debbaf730b692',
      'native_key' => 'rememberthis',
      'filename' => 'modNamespace/fd6103b26424ced545ace7e706f1d5aa.vehicle',
      'namespace' => 'rememberthis',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd061c92faf47fb63e3c7053f0a19d208',
      'native_key' => 'rememberthis.rowTpl',
      'filename' => 'modSystemSetting/c013c693fe79e7afd969c62b53b5a7e3.vehicle',
      'namespace' => 'rememberthis',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54080f597f57c1f8c84c5ade091e5d89',
      'native_key' => 'rememberthis.outerTpl',
      'filename' => 'modSystemSetting/83d1126646df752e00b5639a9012e835.vehicle',
      'namespace' => 'rememberthis',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84d2fccf0607c105e1379907807ae512',
      'native_key' => 'rememberthis.wrapperTpl',
      'filename' => 'modSystemSetting/03209923439299c7ad94f82219660293.vehicle',
      'namespace' => 'rememberthis',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93414c41a285c3581b2bebb9ca223e25',
      'native_key' => 'rememberthis.addTpl',
      'filename' => 'modSystemSetting/d4c460d9be024a4305ca0f384709f2c5.vehicle',
      'namespace' => 'rememberthis',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '739d34cba603032907eec1c859db05b7',
      'native_key' => 'rememberthis.noResultsTpl',
      'filename' => 'modSystemSetting/1a5a50400d3ba15b596e46179c90a492.vehicle',
      'namespace' => 'rememberthis',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d93ecde2cc23d6be866ad7b86235dbd',
      'native_key' => 'rememberthis.scriptTpl',
      'filename' => 'modSystemSetting/73910a64b82c2e10f5d69e2ddbe7c56d.vehicle',
      'namespace' => 'rememberthis',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1a1ea6a58eebde88fbcb5f90c02b765',
      'native_key' => 'rememberthis.showZeroCount',
      'filename' => 'modSystemSetting/9fb1341cf5680b48a492dec78428e5e0.vehicle',
      'namespace' => 'rememberthis',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '973f73edee4b0b02f3081d18f1495eff',
      'native_key' => 'rememberthis.itemTitleTpl',
      'filename' => 'modSystemSetting/0999467281cf2a5d600cb3074e73f58c.vehicle',
      'namespace' => 'rememberthis',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'edf380b45d9f2bd4acb031d61a165f74',
      'native_key' => 'rememberthis.ajaxLoaderImg',
      'filename' => 'modSystemSetting/3541693b5f763753583cf51c2b769965.vehicle',
      'namespace' => 'rememberthis',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1cc87a70877ec8fd04cbb6ae81a8766e',
      'native_key' => 'rememberthis.tvPrefix',
      'filename' => 'modSystemSetting/e849f39e269aaebc18f5d0ee3d12c879.vehicle',
      'namespace' => 'rememberthis',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9a4fd8636dd12e39a1d81f64333524f',
      'native_key' => 'rememberthis.queryAdd',
      'filename' => 'modSystemSetting/07245635733d71503d5ac6afd0c61a87.vehicle',
      'namespace' => 'rememberthis',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79b66acf654eb217376bf6db5264638f',
      'native_key' => 'rememberthis.queryDelete',
      'filename' => 'modSystemSetting/7ad07f0a00c0bbc1505603eb9cea46d6.vehicle',
      'namespace' => 'rememberthis',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8c6cbc85ea813b66ac4a885cdf22a60',
      'native_key' => 'rememberthis.language',
      'filename' => 'modSystemSetting/3349e854e7a79d4b809cac348ec0a92a.vehicle',
      'namespace' => 'rememberthis',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60d51f3b81c34407cc5f8488e5ec4846',
      'native_key' => 'rememberthis.tplPath',
      'filename' => 'modSystemSetting/254dd2e4ecb01caeeacb211ceeccf4e3.vehicle',
      'namespace' => 'rememberthis',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ad2cbfca9edd3510660bda12db7b796',
      'native_key' => 'rememberthis.packagename',
      'filename' => 'modSystemSetting/003c249843f302d6a29861b84cb700fa.vehicle',
      'namespace' => 'rememberthis',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c869d45267ed62b7c33480b3c855d8e',
      'native_key' => 'rememberthis.classname',
      'filename' => 'modSystemSetting/e7326c52ed29cc342ef28a4eedbb156a.vehicle',
      'namespace' => 'rememberthis',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2a7775a57f017c1dd4dbbcb184eb412',
      'native_key' => 'rememberthis.keyname',
      'filename' => 'modSystemSetting/9114c58ca709e2dc6d9c6f03b3e4bfb4.vehicle',
      'namespace' => 'rememberthis',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20d129301f82af4fa42616da5a5c68b2',
      'native_key' => 'rememberthis.joins',
      'filename' => 'modSystemSetting/960ce40853a70cd19e9b29bc21f18bfa.vehicle',
      'namespace' => 'rememberthis',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02ca507ba40a43a67d5fef3f997aa5f8',
      'native_key' => 'rememberthis.jQueryPath',
      'filename' => 'modSystemSetting/5ad3737080f21a68545afe2a975b7eb3.vehicle',
      'namespace' => 'rememberthis',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32c7698d531e642bf0fd5a397e3a573d',
      'native_key' => 'rememberthis.includeScripts',
      'filename' => 'modSystemSetting/58800a3b0f8f714c9ec3edd870e77074.vehicle',
      'namespace' => 'rememberthis',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f069e0b5b6e569dc17cb3dc4b8ac0097',
      'native_key' => 'rememberthis.includeCss',
      'filename' => 'modSystemSetting/37f89c786696ec615899d7cfabee345c.vehicle',
      'namespace' => 'rememberthis',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6db25ebcf42e9a49528109b3b3dab09',
      'native_key' => 'rememberthis.useCookie',
      'filename' => 'modSystemSetting/a326b2060bbc7d5f4f98673c110a0b95.vehicle',
      'namespace' => 'rememberthis',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '075eef576fb92669f2efe7ab129cd424',
      'native_key' => 'rememberthis.cookieName',
      'filename' => 'modSystemSetting/4121a34b6bcb14eab89398890f3f31e6.vehicle',
      'namespace' => 'rememberthis',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bdee90d2c7824e8033b1a0e6d3dfe50',
      'native_key' => 'rememberthis.cookieExpireDays',
      'filename' => 'modSystemSetting/5a54a57f9a21dc247d7e60b12548846a.vehicle',
      'namespace' => 'rememberthis',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7af84570935109714ddadc362132dbe8',
      'native_key' => 'rememberthis.useDatabase',
      'filename' => 'modSystemSetting/dcf6f0edd4cbfe6c69eeda8855573d37.vehicle',
      'namespace' => 'rememberthis',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50aace4475d2376eaa546b9a1f4bd4c0',
      'native_key' => 'rememberthis.debug',
      'filename' => 'modSystemSetting/00da105d69a19962f528c23a3ed40718.vehicle',
      'namespace' => 'rememberthis',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3cc407f445bff10fd660b24622501e07',
      'native_key' => NULL,
      'filename' => 'modCategory/09da3c982b6f05de37a9ff0e3e5496a5.vehicle',
      'namespace' => 'rememberthis',
    ),
  ),
);