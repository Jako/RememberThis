<?php
/**
 * RememberThis
 *
 * Copyright 2008-2024 by Thomas Jakobi <office@treehillstudio.com>
 *
 * @package rememberthis
 * @subpackage classfile
 */

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

/**
 * class RememberThis
 */
class RememberThis extends \TreehillStudio\RememberThis\RememberThis
{
}
