<?php
/**
 * Default Lexicon Entries for RememberThis
 *
 * @package rememberthis
 * @subpackage lexicon
 */
$_lang['rememberthis'] = 'RememberThis';
$_lang['rememberthis.add'] = 'Merken';
$_lang['rememberthis.delete'] = 'Entfernen';
$_lang['rememberthis.noresultstext'] = 'Die Liste ist leer';
