<?php
/**
 * RememberThisList Snippet
 *
 * @package rememberthis
 * @subpackage snippet
 */
$corePath = $modx->getOption('rememberthis.core_path', null, $modx->getOption('core_path') . 'components/rememberthis/');
$rememberthis = $modx->getService('rememberthis', 'RememberThis', $corePath . 'model/rememberthis/', $scriptProperties);
$rememberthis->init();

// Snippet settings
$options = array(
    'rowTpl' => $rememberthis->getOption('rowTpl', $scriptProperties, 'tplRememberThisRow', true),
    'outerTpl' => $rememberthis->getOption('outerTpl', $scriptProperties, 'tplRememberThisOuter', true),
    'noResultsTpl' => $rememberthis->getOption('noResultsTpl', $scriptProperties, 'tplRememberThisNoResults', true),
    'scriptTpl' => $rememberthis->getOption('scriptTpl', $scriptProperties, 'tplRememberThisScript', true),
    'jsonList' => $rememberthis->getOption('jsonList', $scriptProperties, 0, true)
);

$result = $rememberthis->showList($options);
if ($modx->getOption('jsonList', $scriptProperties, 0)) {
    $output = json_encode($result['list']);
} else {
    $output = $result['result'];
}
return $output;