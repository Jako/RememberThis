<?php
$_lang['rememberthis.rememberthisadd.addId'] = 'This value (and the correspondenting item title) is added to the list.';
$_lang['rememberthis.rememberthisadd.addTpl'] = 'Template for the add link.';
$_lang['rememberthis.rememberthislist.rowTpl'] = 'Row template for the list output.';
$_lang['rememberthis.rememberthislist.outerTpl'] = 'Outer template for the list output, if the list is not empty.';
$_lang['rememberthis.rememberthislist.noResultsTpl'] = 'Template that is displayed, if the list is empty.';
$_lang['rememberthis.rememberthislist.scriptTpl'] = 'Template for the javascript call.';
$_lang['rememberthis.rememberthislist.jsonList'] = 'Output a JSON encoded list of element "keyname" values.';
$_lang['rememberthis.rememberthishook.rememberRowTpl'] = 'Row template for the list output.';
$_lang['rememberthis.rememberthishook.rememberOuterTpl'] = 'Outer template for the list output, if the list is not empty.';
